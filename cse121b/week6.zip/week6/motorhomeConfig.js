individual_tire_dictionary = {
    "driver_front" : "",
    "passanger_front" : "",
    "drive_axle_outer_driver" : "",
    "drive_axle_inner_driver" : "",
    "drive_axle_outer_passanger" : "",
    "drive_axle_inner_passanger" : "",
    "tag_axle_driver" : "",
    "tag_axle_passanger" : ""
}

tire_rotation_date = ""
all_tires_combined_bought_new_install_date = "02/2023"
oil_changes_dictionary = {
    "most_recent_oil_change" : 0.00,
    "next_oil_change_millage" : 0.00,
    "replace_oil_by_if_milage_is_not_met_in_a_year": ""
}

trans_fluid_changes_dictionary = {
    "most_recent_trans_fluid_change" : 0.00,
    "next_trans_fluid_change_millage" : 0.00,
    "replace_trans_fluid_by_if_milage_is_not_met_in_a_year": ""
}
previous_odometer_millage = 0.00

export {previous_odometer_millage,trans_fluid_changes_dictionary,oil_changes_dictionary,all_tires_combined_bought_new_install_date,tire_rotation_date,individual_tire_dictionary}